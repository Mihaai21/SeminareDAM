package ro.ase.dam.examen;

import org.junit.Test;

import java.util.List;

import ro.ase.dam.examen.domeniu.Produs;
import ro.ase.dam.examen.grading.GradedTest;
import ro.ase.dam.examen.grading.Punctaj;
import ro.ase.dam.examen.json.ParserJson;

import static org.junit.Assert.assertEquals;

public class R3_ParserJsonTest extends GradedTest {

    private static final String JSON = "["
            + "{\"denumire\":\"Pâine\",\"pret\":5.5,\"stoc\":10},"
            + "{\"denumire\":\"\",\"pret\":1,\"stoc\":1},"
            + "{\"denumire\":\"Lapte\",\"pret\":8,\"stoc\":0}"
            + "]";

    private static final String JSON_ALT = "["
            + "{\"denumire\":\"\",\"pret\":9,\"stoc\":1},"
            + "{\"denumire\":\"A\",\"pret\":2,\"stoc\":3},"
            + "{\"denumire\":\"\",\"pret\":4,\"stoc\":5},"
            + "{\"denumire\":\"B\",\"pret\":6,\"stoc\":7}"
            + "]";

    @Test
    @Punctaj(puncte = 1.0)
    public void r3a_ignoraDenumireGoala() throws Exception {
        assertEquals(2, ParserJson.dinText(JSON).size());
        assertEquals(2, ParserJson.dinText(JSON_ALT).size());
        assertEquals("A", ParserJson.dinText(JSON_ALT).get(0).getDenumire());
        assertEquals("B", ParserJson.dinText(JSON_ALT).get(1).getDenumire());
        assertEquals(0, ParserJson.dinText("[]").size());
    }

    @Test
    @Punctaj(puncte = 1.0)
    public void r3b_mapeazaCampurile() throws Exception {
        List<Produs> list = ParserJson.dinText(JSON);
        assertEquals("Pâine", list.get(0).getDenumire());
        assertEquals(5.5, list.get(0).getPret(), 0.001);
        assertEquals(10, list.get(0).getStoc());
        assertEquals("Lapte", list.get(1).getDenumire());
        assertEquals(8.0, list.get(1).getPret(), 0.001);
        assertEquals(0, list.get(1).getStoc());
    }
}
