package ro.ase.dam.examen;

import org.junit.Test;

import ro.ase.dam.examen.domeniu.Produs;
import ro.ase.dam.examen.domeniu.Validator;
import ro.ase.dam.examen.grading.GradedTest;
import ro.ase.dam.examen.grading.Punctaj;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class R2_ValidatorTest extends GradedTest {

    private Produs ok() {
        return new Produs("Paine", 5.0, 2);
    }

    @Test
    @Punctaj(puncte = 2.0)
    public void r2a_validareProdus() {
        // cazuri valide
        assertTrue(Validator.esteValid(ok()));
        // stoc = 0 → valid (stoc >= 0)
        assertTrue(Validator.esteValid(new Produs("X", 1.0, 0)));

        // null → invalid
        assertFalse(Validator.esteValid(null));
        // denumire null → invalid
        assertFalse(Validator.esteValid(new Produs(null, 5.0, 1)));
        // denumire goala → invalid
        assertFalse(Validator.esteValid(new Produs("", 5.0, 1)));
        // pret = 0 → invalid (pret > 0)
        assertFalse(Validator.esteValid(new Produs("X", 0, 1)));
        // pret < 0 → invalid
        assertFalse(Validator.esteValid(new Produs("X", -1, 1)));
        // stoc < 0 → invalid
        assertFalse(Validator.esteValid(new Produs("X", 5.0, -1)));
    }
}
