package ro.ase.dam.examen;

import org.junit.Test;

import java.util.List;

import ro.ase.dam.examen.domeniu.Produs;
import ro.ase.dam.examen.grading.GradedTest;
import ro.ase.dam.examen.grading.Punctaj;
import ro.ase.dam.examen.xml.ParserXml;

import static org.junit.Assert.assertEquals;

public class R3_ParserXmlTest extends GradedTest {

    private static final String XML = """
            <produse>
              <produs><denumire>Pâine</denumire><pret>5.5</pret><stoc>10</stoc></produs>
              <produs><denumire></denumire><pret>1</pret><stoc>1</stoc></produs>
              <produs><denumire>Lapte</denumire><pret>8</pret><stoc>0</stoc></produs>
            </produse>
            """;

    private static final String XML_ALT = """
            <produse>
              <produs><denumire></denumire><pret>9</pret><stoc>1</stoc></produs>
              <produs><denumire>A</denumire><pret>2</pret><stoc>3</stoc></produs>
              <produs><denumire></denumire><pret>4</pret><stoc>5</stoc></produs>
              <produs><denumire>B</denumire><pret>6</pret><stoc>7</stoc></produs>
            </produse>
            """;

    @Test
    @Punctaj(puncte = 1.0)
    public void r3a_ignoraDenumireGoala() throws Exception {
        assertEquals(2, ParserXml.dinText(XML).size());
        assertEquals(2, ParserXml.dinText(XML_ALT).size());
        assertEquals("A", ParserXml.dinText(XML_ALT).get(0).getDenumire());
        assertEquals("B", ParserXml.dinText(XML_ALT).get(1).getDenumire());
        assertEquals(0, ParserXml.dinText("<produse></produse>").size());
    }

    @Test
    @Punctaj(puncte = 1.0)
    public void r3b_mapeazaCampurile() throws Exception {
        List<Produs> list = ParserXml.dinText(XML);
        assertEquals("Pâine", list.get(0).getDenumire());
        assertEquals(5.5, list.get(0).getPret(), 0.001);
        assertEquals(10, list.get(0).getStoc());
        assertEquals("Lapte", list.get(1).getDenumire());
        assertEquals(8.0, list.get(1).getPret(), 0.001);
        assertEquals(0, list.get(1).getStoc());
    }
}
