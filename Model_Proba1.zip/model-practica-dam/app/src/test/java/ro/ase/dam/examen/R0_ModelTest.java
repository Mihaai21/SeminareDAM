package ro.ase.dam.examen;

import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import ro.ase.dam.examen.domeniu.Produs;
import ro.ase.dam.examen.grading.GradedTest;
import ro.ase.dam.examen.grading.Punctaj;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class R0_ModelTest extends GradedTest {

    @Test
    @Punctaj(puncte = 2.0)
    public void r0a_constructorSiGettersSiSetters() {
        Produs p = new Produs("Paine", 5.0, 10);
        assertEquals("Paine", p.getDenumire());
        assertEquals(5.0, p.getPret(), 0.001);
        assertEquals(10, p.getStoc());

        // al doilea obiect - anti-singleton hardcodat
        Produs p2 = new Produs("Lapte", 8.5, 0);
        assertEquals("Lapte", p2.getDenumire());
        assertEquals(8.5, p2.getPret(), 0.001);
        assertEquals(0, p2.getStoc());

        // setters
        p2.setDenumire("Lapte 2%");
        p2.setPret(9.0);
        p2.setStoc(5);
        assertEquals("Lapte 2%", p2.getDenumire());
        assertEquals(9.0, p2.getPret(), 0.001);
        assertEquals(5, p2.getStoc());

        // toString
        String s = p.toString();
        assertTrue(s.contains("Paine"));
        assertTrue(s.contains("5") || s.contains("5.0"));

        // campuri private
        Set<String> names = new HashSet<>();
        int privateFields = 0;
        for (Field f : Produs.class.getDeclaredFields()) {
            if (f.isSynthetic()) continue;
            if (Modifier.isPrivate(f.getModifiers())) {
                privateFields++;
                names.add(f.getName());
            }
        }
        assertTrue("Campurile trebuie sa fie private", privateFields >= 3);
        assertTrue(names.containsAll(Arrays.asList("denumire", "pret", "stoc")));
    }
}
