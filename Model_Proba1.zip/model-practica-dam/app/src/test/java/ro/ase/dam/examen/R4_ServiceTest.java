package ro.ase.dam.examen;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import ro.ase.dam.examen.domeniu.Produs;
import ro.ase.dam.examen.domeniu.ProduseService;
import ro.ase.dam.examen.grading.GradedTest;
import ro.ase.dam.examen.grading.Punctaj;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class R4_ServiceTest extends GradedTest {

    private Produs p(String denumire, int stoc) {
        return new Produs(denumire, 10.0, stoc);
    }

    @Test
    @Punctaj(puncte = 2.0)
    public void r4a_filtreazaInStoc() {
        List<Produs> sursa = new ArrayList<>(Arrays.asList(
                p("A", 5), p("B", 0), p("C", 3)));
        List<Produs> inStoc = ProduseService.filtreazaInStoc(sursa);
        assertEquals(2, inStoc.size());
        assertTrue(inStoc.stream().allMatch(pr -> pr.getStoc() > 0));
        assertEquals(Arrays.asList("A", "C"),
                inStoc.stream().map(Produs::getDenumire).collect(Collectors.toList()));

        // lista goala → empty
        assertEquals(0, ProduseService.filtreazaInStoc(Collections.emptyList()).size());
        // null → empty list
        List<Produs> dinNull = ProduseService.filtreazaInStoc(null);
        assertNotNull(dinNull);
        assertEquals(0, dinNull.size());

        // toti cu stoc 0 → empty
        assertEquals(0, ProduseService.filtreazaInStoc(
                Arrays.asList(p("X", 0), p("Y", 0))).size());

        // nu modifica lista originala
        assertEquals(3, sursa.size());
        sursa.remove(0);
        assertEquals(2, inStoc.size());
    }
}
