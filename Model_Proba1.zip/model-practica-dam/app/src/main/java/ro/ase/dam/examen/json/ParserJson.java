package ro.ase.dam.examen.json;

import java.util.List;

import ro.ase.dam.examen.domeniu.Produs;

public final class ParserJson {

    private ParserJson() {}

    public static List<Produs> dinText(String text) throws Exception {
        // TODO: parsați vectorul JSON → List<Produs>; săriți denumirile goale
        throw new UnsupportedOperationException("TODO");
    }
}
