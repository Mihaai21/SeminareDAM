package ro.ase.dam.examen.domeniu;

public final class Validator {

    private Validator() {}

    public static boolean esteValid(Produs p) {
        // TODO
        throw new UnsupportedOperationException("TODO");
    }
}
