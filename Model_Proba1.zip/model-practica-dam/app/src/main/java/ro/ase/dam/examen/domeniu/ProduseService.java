package ro.ase.dam.examen.domeniu;

import java.util.List;

public final class ProduseService {

    private ProduseService() {}

    public static List<Produs> filtreazaInStoc(List<Produs> sursa) {
        // TODO
        throw new UnsupportedOperationException("TODO");
    }
}
