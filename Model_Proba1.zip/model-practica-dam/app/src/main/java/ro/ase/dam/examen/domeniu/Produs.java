package ro.ase.dam.examen.domeniu;

public class Produs {

    // TODO: campuri private

    public Produs(String denumire, double pret, int stoc) {
        // TODO
    }

    public String getDenumire() {
        // TODO
        return null;
    }

    public void setDenumire(String denumire) {
        // TODO
    }

    public double getPret() {
        // TODO
        return 0;
    }

    public void setPret(double pret) {
        // TODO
    }

    public int getStoc() {
        // TODO
        return 0;
    }

    public void setStoc(int stoc) {
        // TODO
    }

    @Override
    public String toString() {
        // TODO
        return "";
    }
}
