package ro.ase.dam.examen.xml;

import java.util.List;

import ro.ase.dam.examen.domeniu.Produs;

public final class ParserXml {

    private ParserXml() {}

    public static List<Produs> dinText(String text) throws Exception {
        // TODO: parsați nodurile <produs> → List<Produs>; săriți denumirile goale
        throw new UnsupportedOperationException("TODO");
    }
}
