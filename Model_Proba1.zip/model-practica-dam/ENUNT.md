# Proba practică 1 - model de practică
## Timp de lucru: ~30-40 de minute

Acesta este un **model de practică**, ca să vă obișnuiți cu structura probei (enunț + proiect + teste unitare ponderate). Enunțul, cerințele și timpul de lucru de la proba reală vor fi diferite și mai cuprinzătoare.

Nota obținută în testele unitare este **orientativă**.

Completați metodele și golurile din proiect până când trec cât mai multe dintre teste.

## Despre aplicație

Aplicația gestionează o listă simplă de produse. Un produs are:

- `denumire` - `String`
- `pret` - `double`
- `stoc` - `int`

## Cerințe

**1. Model (2p)**  
Definiți câmpurile, constructorul, metodele accesor și `toString()`. Câmpurile de stare trebuie să fie private.

**2. Validare (2p)**  
Denumirea nu poate fi goală (nici `null`), prețul trebuie să fie strict pozitiv, iar stocul nu poate fi negativ. Un produs `null` nu este valid.

**3. Import JSON (2p)**  
Parsați un vector de obiecte JSON și construiți lista de produse. Săriți înregistrările cu denumirea goală.

**4. Import XML (2p)**  
Parsați un document XML cu noduri `<produs>` și construiți lista de produse. Săriți înregistrările cu denumirea goală.

**5. Filtrare (2p)**  
Returnați doar produsele cu stoc strict pozitiv. Dacă sursa e goală sau `null`, returnați o listă goală.

Mult succes!
